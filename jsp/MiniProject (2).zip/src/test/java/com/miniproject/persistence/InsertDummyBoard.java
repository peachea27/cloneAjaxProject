package com.miniproject.persistence;

import javax.inject.Inject;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.miniproject.model.HBoardDTO;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "file:src/main/webapp/WEB-INF/spring/**/root-context.xml" })
public class InsertDummyBoard {

	@Inject
	private HBoardDAO dao;

	@Test
	public void insertDummyDataBoard() {
		for (int i = 0; i < 300; i++) {
			HBoardDTO dto = HBoardDTO.builder().title("dummy title" + i + "....").content("dummy content")
					.writer("tosimi").build();
			try {
				if (dao.insertNewBoard(dto) == 1) {
					int newBoardNo = dao.selectMaxBoardNo();
					// 1-1-1) 1-1)에서 가져온 글 번호를 ref칼럼에 update
					dao.updateBoardRef(newBoardNo);
					// 1-2) 1-1)에서 얻어온 게시글 번호를 참조하는 첨부파일정보를 insert해야 한다.
				}
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
	}
}
