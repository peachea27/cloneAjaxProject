package com.miniproject.persistence;

import java.util.List;

import com.miniproject.model.BoardDetailInfo;
import com.miniproject.model.BoardUpFilesVODTO;
import com.miniproject.model.HBoardDTO;
import com.miniproject.model.HBoardReplyDTO;
import com.miniproject.model.HBoardVO;
import com.miniproject.model.PagingInfo;
import com.miniproject.model.SearchCriteriaDTO;

public interface CBoardDAO {
	// 게시판 전체 목록 가져오는 메서드
	List<HBoardVO> selectAllBoard(PagingInfo pi) throws Exception;

	// 게시글 저장
	public int insertNewBoard(HBoardDTO newBoard) throws Exception;

	// 최근 저장된 글의 글번호를 얻어오는 메서드
	int selectMaxBoardNo() throws Exception;

	// 업로드된 첨부파일 저장하는 메서드
	int insertBoardUpFile(BoardUpFilesVODTO file);

	// 게시판 글 조회
	HBoardDTO selectBoardByNo(int boardNo) throws Exception;

	// 파일리스트 가져오기
	List<BoardUpFilesVODTO> selectFileByNo(int boardNo) throws Exception;

	// resultmap 테스트
	HBoardDTO testResultMap(int boardNo) throws Exception;

	// 게시글 상세정보
	BoardDetailInfo selectBoardDetailByBoardNo(int boardNo) throws Exception;

	// 날짜계산
	int selectDateDiff(String ipAddr, int boardNo) throws Exception;

	// 특정 ip사용자가 게시글을 확인한 로그를 삽입!
	int insertBoardReadLog(String ipAddr, int boardNo) throws Exception;

	// 조회수 업데이트
	int updateReadCount(int boardNo) throws Exception;

	// 24시간이 지났을때 시간 업데이트
	int updateReadWhen(String ipAddr, int boardNo) throws Exception;

	// 저장된 게시글의 글 번호를 ref칼럼에 update
	void updateBoardRef(int newBoardNo) throws Exception;

	// refOrder 업데이트
	void updateRefOrder(int ref, int refOrder) throws Exception;

	// 답글 저장
	int insertReplyBoard(HBoardReplyDTO replyBoard) throws Exception;

	// 게시글 삭제
	int removeBoardByNo(int boardNo) throws Exception;

	// 업로드 파일 삭제
	void deleteAllBoardUpFiles(int boardNo) throws Exception;

	// 게시판 수정
	int updateBoard(HBoardDTO modifyBoard) throws Exception;

	// 수정 게시판에서 체크된 기본 업로드 파일 삭제
	void deleteBoardUpFile(int boardUpFileNo) throws Exception;

	// 게시글 전체 수
	int getTotalPostCnt() throws Exception;

	// 게시글 목록 조회 -- 검색어 + 페이징
	List<HBoardVO> selectAllBoard(PagingInfo pi, SearchCriteriaDTO searchCriteriaDTO) throws Exception;

	// 검색된 게시글 수
	int getTotalPostCnt(SearchCriteriaDTO searchCriteriaDTO) throws Exception;

	// 게시글 좋아요
	int likeBoard(int boardNo, String who) throws Exception;

	// 좋아요 수 업데이트
	int updateBoardLikeCount(int i, int boardNo) throws Exception;

	int dislikeBoard(int boardNo, String who) throws Exception;

	List<String> selectPeopleWhoLikeBoard(int boardNo) throws Exception;
}
