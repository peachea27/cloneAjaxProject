package com.miniproject.persistence;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;

import com.miniproject.model.BoardDetailInfo;
import com.miniproject.model.BoardUpFilesVODTO;
import com.miniproject.model.HBoardDTO;
import com.miniproject.model.HBoardReplyDTO;
import com.miniproject.model.HBoardVO;
import com.miniproject.model.PagingInfo;
import com.miniproject.model.SearchCriteriaDTO;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Repository // �Ʒ��� Ŭ������ DAO��ü���� ���
public class HBoardDAOImpl implements HBoardDAO {

	@Inject
	private SqlSession ses;

	private static String ns = "com.miniproject.mappers.hboardmapper.";

	@Override
	public List<HBoardVO> selectAllBoard(PagingInfo pi) {
		return ses.selectList(ns + "getAllHBoard", pi);
	}

	@Override
	public int insertNewBoard(HBoardDTO newBoard) throws Exception {
		int result = ses.insert(ns + "saveNewBoard", newBoard);
		return result;
	}

	@Override
	public int selectMaxBoardNo() throws Exception {
		return ses.selectOne(ns + "getMaxNo");
	}

	@Override
	public int insertBoardUpFile(BoardUpFilesVODTO file) {
		return ses.insert(ns + "saveUpFile", file);
	}

	@Override
	public HBoardDTO selectBoardByNo(int boardNo) throws Exception {
		// TODO Auto-generated method stub
		return ses.selectOne(ns + "getBoardByNo", boardNo);
	}

	@Override
	public List<BoardUpFilesVODTO> selectFileByNo(int boardNo) throws Exception {
		return ses.selectList(ns + "getFilesByNo", boardNo);
	}

	@Override
	public HBoardDTO testResultMap(int boardNo) throws Exception {
		return ses.selectOne(ns + "selectResultmapTest", boardNo);
	}

	@Override
	public List<BoardDetailInfo> selectBoardDetailByBoardNo(int boardNo) throws Exception {
		return ses.selectList(ns + "selectBoardDetailInfoByBoardNo", boardNo);
	}

	@Override
	public int selectDateDiff(String ipAddr, int boardNo) throws Exception {
		Map<String, Object> args = new HashMap<String, Object>();
		args.put("readWho", ipAddr);
		args.put("boardNo", boardNo);
		return ses.selectOne(ns + "selectBoardDateDiff", args);
	}

	@Override
	public int insertBoardReadLog(String ipAddr, int boardNo) throws Exception {
		Map<String, Object> args = new HashMap<String, Object>();
		args.put("readWho", ipAddr);
		args.put("boardNo", boardNo);
		return ses.insert(ns + "saveBoardReadLog", args);
	}

	@Override
	public int updateReadCount(int boardNo) throws Exception {
		return ses.update(ns + "updateReadCount", boardNo);
	}

	@Override
	public int updateReadWhen(String ipAddr, int boardNo) throws Exception {
		Map<String, Object> args = new HashMap<String, Object>();
		args.put("readWho", ipAddr);
		args.put("boardNo", boardNo);
		return ses.update(ns + "updateBoardReadLog", args);
	}

	@Override
	public void updateBoardRef(int newBoardNo) throws Exception {
		ses.update(ns + "updateBoardRef", newBoardNo);
	}

	@Override
	public void updateRefOrder(int ref, int refOrder) throws Exception {
		Map<String, Object> args = new HashMap<String, Object>();
		args.put("ref", ref);
		args.put("refOrder", refOrder);

		ses.update(ns + "updateBoardRefOrder", args);
	}

	@Override
	public int insertReplyBoard(HBoardReplyDTO replyBoard) throws Exception {
		return ses.insert(ns + "insertReplyBoard", replyBoard);
	}

	@Override
	public int removeBoardByNo(int boardNo) throws Exception {
		return ses.update(ns + "updateIsDelete", boardNo);

	}

	@Override
	public void deleteAllBoardUpFiles(int boardNo) throws Exception {
		ses.delete(ns + "deleteBoardUpfileByPK", boardNo);
	}

	@Override
	public int updateBoard(HBoardDTO modifyBoard) throws Exception {
		return ses.update(ns + "updateBoard", modifyBoard);
	}

	@Override
	public void deleteBoardUpFile(int boardUpFileNo) throws Exception {
		ses.delete(ns + "deleteBoardUpFileByFileNo", boardUpFileNo);
	}

	@Override
	public int getTotalPostCnt() throws Exception {
		return ses.selectOne(ns + "selectTotalCount");
	}

	@Override
	public List<HBoardVO> selectAllBoard(PagingInfo pi, SearchCriteriaDTO searchCriteriaDTO) throws Exception {
		Map<String, Object> args = new HashMap<String, Object>();
		args.put("startRowIndex", pi.getStartRowIndex());
		args.put("viewPostCntPerPage", pi.getViewPostCntPerPage());
		args.put("searchType", searchCriteriaDTO.getSearchType());
		args.put("searchWord", "%" + searchCriteriaDTO.getSearchWord() + "%");
		return ses.selectList(ns + "getSearchBoard", args);

	}

	@Override
	public int getTotalPostCnt(SearchCriteriaDTO searchCriteriaDTO) throws Exception {
		Map<String, Object> args = new HashMap<String, Object>();
		args.put("searchType", searchCriteriaDTO.getSearchType());
		args.put("searchWord", "%" + searchCriteriaDTO.getSearchWord() + "%");
		return ses.selectOne(ns + "countSearchBoard", args);
	}

}
