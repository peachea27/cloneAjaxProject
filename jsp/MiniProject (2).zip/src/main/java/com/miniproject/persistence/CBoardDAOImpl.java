package com.miniproject.persistence;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;

import com.miniproject.model.BoardDetailInfo;
import com.miniproject.model.BoardUpFilesVODTO;
import com.miniproject.model.HBoardDTO;
import com.miniproject.model.HBoardReplyDTO;
import com.miniproject.model.HBoardVO;
import com.miniproject.model.PagingInfo;
import com.miniproject.model.SearchCriteriaDTO;

import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@Repository
public class CBoardDAOImpl implements CBoardDAO {

	private static final String NS = "com.miniproject.mappers.cboardmapper.";
	private final SqlSession ses;

	@Override
	public List<HBoardVO> selectAllBoard(PagingInfo pi) throws Exception {
		List<HBoardVO> lst = ses.selectList(NS + "getAllHBoard", pi);
		return lst;
	}

	@Override
	public int insertNewBoard(HBoardDTO newBoard) throws Exception {
		int result = ses.insert(NS + "saveNewBoard", newBoard);
		return result;
	}

	@Override
	public int selectMaxBoardNo() throws Exception {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int insertBoardUpFile(BoardUpFilesVODTO file) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public HBoardDTO selectBoardByNo(int boardNo) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<BoardUpFilesVODTO> selectFileByNo(int boardNo) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public HBoardDTO testResultMap(int boardNo) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public BoardDetailInfo selectBoardDetailByBoardNo(int boardNo) throws Exception {
		return ses.selectOne(NS + "selectBoardDetailInfoByBoardNo", boardNo);
	}

	@Override
	public int selectDateDiff(String ipAddr, int boardNo) throws Exception {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int insertBoardReadLog(String ipAddr, int boardNo) throws Exception {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int updateReadCount(int boardNo) throws Exception {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int updateReadWhen(String ipAddr, int boardNo) throws Exception {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void updateBoardRef(int newBoardNo) throws Exception {
		// TODO Auto-generated method stub

	}

	@Override
	public void updateRefOrder(int ref, int refOrder) throws Exception {
		// TODO Auto-generated method stub

	}

	@Override
	public int insertReplyBoard(HBoardReplyDTO replyBoard) throws Exception {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int removeBoardByNo(int boardNo) throws Exception {
		return ses.update(NS + "updateIsDelete", boardNo);
	}

	@Override
	public void deleteAllBoardUpFiles(int boardNo) throws Exception {
		// TODO Auto-generated method stub

	}

	@Override
	public int updateBoard(HBoardDTO modifyBoard) throws Exception {
		return ses.update(NS + "updateBoard", modifyBoard);
	}

	@Override
	public void deleteBoardUpFile(int boardUpFileNo) throws Exception {
		// TODO Auto-generated method stub

	}

	@Override
	public int getTotalPostCnt() throws Exception {
		return ses.selectOne(NS + "selectTotalCount");
	}

	@Override
	public List<HBoardVO> selectAllBoard(PagingInfo pi, SearchCriteriaDTO searchCriteriaDTO) throws Exception {
		Map<String, Object> args = new HashMap<String, Object>();
		args.put("startRowIndex", pi.getStartRowIndex());
		args.put("viewPostCntPerPage", pi.getViewPostCntPerPage());
		args.put("searchType", searchCriteriaDTO.getSearchType());
		args.put("searchWord", "%" + searchCriteriaDTO.getSearchWord() + "%");
		return ses.selectList(NS + "getSearchBoard", args);
	}

	@Override
	public int getTotalPostCnt(SearchCriteriaDTO searchCriteriaDTO) throws Exception {
		Map<String, Object> args = new HashMap<String, Object>();
		args.put("searchType", searchCriteriaDTO.getSearchType());
		args.put("searchWord", "%" + searchCriteriaDTO.getSearchWord() + "%");
		return ses.selectOne(NS + "countSearchBoard", args);
	}

	@Override
	public int likeBoard(int boardNo, String who) throws Exception {
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("who", who);
		params.put("boardNo", boardNo);
		return ses.insert(NS + "like", params);
	}

	@Override
	public int updateBoardLikeCount(int n, int boardNo) throws Exception {
		System.out.println("DAO단 좋아요 업데이트 ");
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("n", n);
		params.put("boardNo", boardNo);
		return ses.update(NS + "updateLikeCount", params);
	}

	@Override
	public int dislikeBoard(int boardNo, String who) throws Exception {
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("who", who);
		params.put("boardNo", boardNo);
		return ses.delete(NS + "dislike", params);
	}

	@Override
	public List<String> selectPeopleWhoLikeBoard(int boardNo) throws Exception {
		return ses.selectList(NS + "selectUserWhoLike", boardNo);
	}

}
