package com.miniproject.model;

public enum BoardUpFileStatus {
	INSERT, DELETE
}
