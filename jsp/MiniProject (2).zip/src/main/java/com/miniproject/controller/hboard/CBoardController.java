package com.miniproject.controller.hboard;

import java.util.List;
import java.util.Map;

import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.miniproject.model.BoardDetailInfo;
import com.miniproject.model.HBoardDTO;
import com.miniproject.model.HBoardVO;
import com.miniproject.model.PagingInfo;
import com.miniproject.model.PagingInfoDTO;
import com.miniproject.model.SearchCriteriaDTO;
import com.miniproject.service.hboard.CBoardService;
import com.miniproject.util.GetClientIPAddr;

@Controller
@RequestMapping("/cboard")
public class CBoardController {

	private static final Logger logger = LoggerFactory.getLogger(CBoardController.class);

	@Inject
	private CBoardService service;

	@RequestMapping("/listAll") // cboard/listAll
	public void listAll(Model model, @RequestParam(value = "pageNo", defaultValue = "1") int pageNo,
			@RequestParam(value = "pagingSize", defaultValue = "10") int pagingSize,
			SearchCriteriaDTO searchCriteriaDTO) {
		System.out.println(pageNo + " " + pagingSize);
		System.out.println(searchCriteriaDTO.toString());
		PagingInfoDTO dto = PagingInfoDTO.builder().pageNo(pageNo).pagingSize(pagingSize).build();
		List<HBoardVO> lst = null;
		try {
			Map<String, Object> resultMap = service.getAllBoard(dto, searchCriteriaDTO);
			lst = (List<HBoardVO>) resultMap.get("boardList");
			PagingInfo pi = (PagingInfo) resultMap.get("pagingInfo");
// 			lst = service.getAllBoard(dto, searchCriteriaDTO);
//			lst = (List<HBoardVO>) result.get("boardList");

			model.addAttribute("boardList", lst);
			model.addAttribute("pagingInfo", pi);
			model.addAttribute("search", searchCriteriaDTO);

		} catch (Exception e) {
			e.printStackTrace();
			model.addAttribute("exception", "error");
		}

//		for (HBoardVO b :lst) {
//			System.out.println(b.toString());
//		}

	}

	@RequestMapping(value = "/showSaveBoardForm", method = RequestMethod.GET)
	public void showSaveBoardForm() { // 게시판 글 저장페이지를 출력하는 메서드
	}

	@RequestMapping(value = "/saveBoard", method = RequestMethod.POST)
	public String saveBoard(HBoardDTO boardDTO, RedirectAttributes rttr) {
		System.out.println("글저장 : " + boardDTO.toString());

		try {
			if (service.saveBoard(boardDTO)) {

				rttr.addAttribute("status", "success");
			}
		} catch (Exception e) {
			e.printStackTrace();
			rttr.addAttribute("status", "fail");

		}

		return "redirect:/cboard/listAll"; // 게시글 전체 목록 페이지로 돌아감.
	}

	// --------------------게시글 상세페이지 ------------------------------

	// 아래의 viewBoard()는 /viewBoard(게시글 상세보기), /modifyBoard(게시글 수정하기 위해 게시글을 불러오기
	// 위함)일 때
	// 2번 호출된다.
	@GetMapping(value = { "/viewBoard", "/modifyBoard" })
	public String viewBoard(@RequestParam(value = "boardNo", defaultValue = "-1") int boardNo, Model model,
			HttpServletRequest request) {
		System.out.println(request.getRequestURI());

		List<String> peopleLike = null;
		BoardDetailInfo boarderDetailInfo = null;

		String ipAddr = GetClientIPAddr.getClientIp(request);
		String returnViewPage = "";

		if (boardNo == -1) {
			return "redirect:/cboard/listAll";
		} else {
			try {
				if (request.getRequestURI().equals("/cboard/viewBoard")) {
					System.out.println("게시글 상세보기 호출");
					boarderDetailInfo = service.read(boardNo, ipAddr);
					peopleLike = service.selectPeopleWhoLike(boardNo);
					returnViewPage = "/cboard/viewBoard";
				} else if (request.getRequestURI().equals("/cboard/modifyBoard")) {
					boarderDetailInfo = service.read(boardNo);
					returnViewPage = "/cboard/modifyBoard";
				}

			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				returnViewPage = "redirect:/cboard/listAll?status=fail";
			}

			model.addAttribute("boardDetailInfo", boarderDetailInfo);
			model.addAttribute("peopleWhoLike", peopleLike);
			return returnViewPage;
		}

	}

	// 답글처리
	@GetMapping("/showReplyForm")
	public String showReplyForm() {
		return "/hboard/replyForm";
	}

	// 게시글 삭제
	@RequestMapping("/removeBoard")
	public String removeBoard(@RequestParam("boardNo") int boardNo, HttpServletRequest request, RedirectAttributes rttr)
			throws Exception {
		String returnPage = null;
		if (service.removeBoardByNo(boardNo) == 1) {
			System.out.println("삭제 성공");
			returnPage = "redirect:/cboard/listAll";
			rttr.addAttribute("status", "success");
		} else {
			System.out.println("삭제 실패");
			returnPage = "redirect:/cboard/viewBoard?" + boardNo;
			rttr.addAttribute("status", "fail");
		}
		return returnPage;
	}

	@RequestMapping(value = "/modifyBoardSave", method = RequestMethod.POST)
	public String modifyBoardSave(HBoardDTO modifyBoard, HttpServletRequest request, RedirectAttributes rttr) {
		String redirectPath = "redirect:/cboard/viewBoard?boardNo=" + modifyBoard.getBoardNo();
		System.out.println(modifyBoard.toString() + "수정");
		try {
			// DB에 저장
			if (service.updateBoard(modifyBoard)) {
				System.out.println("수정완료");
				rttr.addAttribute("status", "success");
			}

		} catch (Exception e) {
			e.printStackTrace();
			rttr.addAttribute("status", "fail");
		}
//		modifyFileList.clear();
		return redirectPath;
	}

	@PostMapping("/boardlike")
	public ResponseEntity<String> likeDislike(@RequestParam("who") String who, @RequestParam("boardNo") int boardNo,
			@RequestParam("like") String like) {
		logger.info(who + "님이" + boardNo + "번 글을 " + like);

		ResponseEntity<String> result = null;
		boolean dbResult = false;
		try {
			if (like.equals("like")) {
				dbResult = service.likeBoard(boardNo, who);
			} else if (like.equals("dislike")) {
				dbResult = service.dislikeBoard(boardNo, who);
			}

			if (dbResult) {
				result = new ResponseEntity<String>("success", HttpStatus.OK);
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			result = new ResponseEntity<String>("fail", HttpStatus.CONFLICT);
		}
		return result;
	}
}
