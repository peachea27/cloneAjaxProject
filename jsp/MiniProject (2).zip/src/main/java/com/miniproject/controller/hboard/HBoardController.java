package com.miniproject.controller.hboard;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.miniproject.model.BoardDetailInfo;
import com.miniproject.model.BoardUpFileStatus;
import com.miniproject.model.BoardUpFilesVODTO;
import com.miniproject.model.HBoardDTO;
import com.miniproject.model.HBoardReplyDTO;
import com.miniproject.model.HBoardVO;
import com.miniproject.model.MyResponseWithoutData;
import com.miniproject.model.PagingInfo;
import com.miniproject.model.PagingInfoDTO;
import com.miniproject.model.SearchCriteriaDTO;
import com.miniproject.service.hboard.HBoardService;
import com.miniproject.util.FileProcess;
import com.miniproject.util.GetClientIPAddr;

@Controller
@RequestMapping("/hboard")
public class HBoardController {

	private static final Logger logger = LoggerFactory.getLogger(HBoardController.class);

	// 유저가 업로드한 파일을 임시 보관하는 객체 (컬렉션)
	private List<BoardUpFilesVODTO> uploadFileList = new ArrayList<>();

	// 수정 요청시 유저가 업로드한 파일을 저장
	private List<BoardUpFilesVODTO> modifyFileList = new ArrayList<>();
	@Inject
	private HBoardService service;
	@Inject
	private FileProcess fileProcess; // FileProcess객체 주입

	@RequestMapping("/listAll") // hboard/listAll��û��
	public void listAll(Model model, @RequestParam(value = "pageNo", defaultValue = "1") int pageNo,
			@RequestParam(value = "pagingSize", defaultValue = "10") int pagingSize,
			SearchCriteriaDTO searchCriteriaDTO) {
		System.out.println(pageNo + " " + pagingSize);
		System.out.println(searchCriteriaDTO.toString());
		PagingInfoDTO dto = PagingInfoDTO.builder().pageNo(pageNo).pagingSize(pagingSize).build();
		List<HBoardVO> lst = null;
		try {
			Map<String, Object> resultMap = service.getAllBoard(dto, searchCriteriaDTO);
			lst = (List<HBoardVO>) resultMap.get("boardList");
			PagingInfo pi = (PagingInfo) resultMap.get("pagingInfo");
// 			lst = service.getAllBoard(dto, searchCriteriaDTO);
//			lst = (List<HBoardVO>) result.get("boardList");

			model.addAttribute("boardList", lst);
			model.addAttribute("pagingInfo", pi);
			model.addAttribute("search", searchCriteriaDTO);

		} catch (Exception e) {
			e.printStackTrace();
			model.addAttribute("exception", "error");
		}

//		for (HBoardVO b :lst) {
//			System.out.println(b.toString());
//		}

	}

	@ResponseBody // json으로 응답
	@RequestMapping("/listAllAjax") // hboard/listAll��û��
	public ResponseEntity<Map<String, Object>> listAllAjax(Model model,
			@RequestParam(value = "pageNo", defaultValue = "1") int pageNo,
			@RequestParam(value = "pagingSize", defaultValue = "10") int pagingSize) {
		System.out.println(pageNo + " " + pagingSize);
		PagingInfoDTO dto = PagingInfoDTO.builder().pageNo(pageNo).pagingSize(pagingSize).build();
		List<HBoardVO> lst = null;
		try {
			Map<String, Object> result = service.getAllBoard(dto);
			lst = (List<HBoardVO>) result.get("boardList");
			PagingInfo pi = (PagingInfo) result.get("pagingInfo");

			// json 반환할 응답 데이터
			return new ResponseEntity<Map<String, Object>>(result, HttpStatus.OK);

		} catch (Exception e) {
			e.printStackTrace();
			Map<String, Object> errorMap = new HashMap<String, Object>();
			errorMap.put("exception", "fail");
			return new ResponseEntity<Map<String, Object>>(errorMap, HttpStatus.CONFLICT);
		}

	}

	@RequestMapping(value = "/saveBoard", method = RequestMethod.GET)
	public String showSaveBoardForm() { // 게시판 글 저장페이지를 출력하는 메서드
		return "/hboard/saveBoardForm";
	}

	@RequestMapping(value = "/saveBoard", method = RequestMethod.POST)
	public String saveBoard(HBoardDTO boardDTO, RedirectAttributes rttr) {
		System.out.println("글저장");

		// 첨부파일 리스트를 boardDTO에 추가
		System.out.println("저장하기 직전 파일리스트 : " + uploadFileList.toString());
		boardDTO.setFileList(uploadFileList);
		String returnPage = "redirect:/hboard/listAll";

		try {
			if (service.saveBoard(boardDTO)) {
				System.out.println("저장완료");

				rttr.addAttribute("status", "success");
			}
		} catch (Exception e) {
			e.printStackTrace();
			rttr.addAttribute("status", "fail");

		}

		// 이전 글의 파일들 저장시 사용된 리스트를 지워주는 작업이 필요하다.
		uploadFileList.clear();

		return returnPage; // 게시글 전체 목록 페이지로 돌아감.
	}

	@RequestMapping(value = "/upfiles", method = RequestMethod.POST)

	public ResponseEntity<MyResponseWithoutData> saveBoardFile(@RequestParam("file") MultipartFile file,
			HttpServletRequest request) {
		System.out.println("파일 전송 요청됨");
		System.out.println("파일의오리지널 이름 : " + file.getOriginalFilename());
		System.out.println("파일의 사이즈 :  " + file.getSize());
		System.out.println("파일의 contentType : :  " + file.getContentType());
		ResponseEntity<MyResponseWithoutData> result = null;
		try {
			BoardUpFilesVODTO fileInfo = fileSave(file, request);
			String tmp = null;
			uploadFileList.add(fileInfo);
			System.out.println("업로드 파일 리스트 :" + uploadFileList.toString());
			if (fileInfo.getThumbFileName() != null) {
				// 이미지O
				tmp = fileInfo.getThumbFileName();
			} else {
				// 이미지X
				tmp = fileInfo.getNewFileName();
			}

			MyResponseWithoutData mrw = MyResponseWithoutData.builder().code(200).msg("success").newFileName(tmp)
					.build();
			result = new ResponseEntity<MyResponseWithoutData>(mrw, HttpStatus.OK);

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			result = new ResponseEntity<>(HttpStatus.NOT_ACCEPTABLE);
		}

		return result;
	}

	private BoardUpFilesVODTO fileSave(MultipartFile file, HttpServletRequest request) throws IOException {
		// 파일의 기본정보 저장
		String originalFileName = file.getOriginalFilename();
		long fileSize = file.getSize();
		String contentType = file.getContentType();
		byte[] upfile = file.getBytes(); // 파일의 실제 데이터 저장

		String realPath = request.getSession().getServletContext().getRealPath("/resources/boardUpFiles");
		System.out.println("서버의 실제 물리적 경로 : " + realPath);

		// 실제파일 저장
		BoardUpFilesVODTO result = fileProcess.saveFileToRealPath(upfile, realPath, contentType, originalFileName,
				fileSize);
		return result;
	}

	@RequestMapping(value = "/removefile", method = RequestMethod.POST)
	public ResponseEntity<MyResponseWithoutData> removeUpFile(@RequestParam("removeFileName") String removeFileName,
			HttpServletRequest request) {
		System.out.println("업로드 된 파일을 삭제 : " + removeFileName);

		ResponseEntity<MyResponseWithoutData> result = null;
		String realPath = request.getSession().getServletContext().getRealPath("/resources/boardUpFiles");

		// 이미지라면
		// 썸네일이미지파일, 오리지널파일 삭제

		// 이미지가 아니라면
		// 오리지널파일만 삭제

		int removeIndex = -1;
		boolean removeResult = false;

		if (removeFileName.contains("thumb_")) {
			for (int i = 0; i < uploadFileList.size(); i++) {
				if (uploadFileList.get(i).getThumbFileName().contains(removeFileName)) {
					System.out.println(i + "번째에서 해당 파일 발견" + uploadFileList.get(i).getThumbFileName());
					if (fileProcess.removeFile(realPath + removeFileName)) {
						removeIndex = i;
						System.out.println(removeFileName + "파일 삭제 완료");
						removeResult = true;
						break;
					}
				}
			}
		} else {
			for (int i = 0; i < uploadFileList.size(); i++) {
				if (uploadFileList.get(i).getNewFileName().contains(removeFileName)) {
					System.out.println(i + "번째에서 해당 파일 발견" + uploadFileList.get(i).getNewFileName());
					if (fileProcess.removeFile(realPath + removeFileName)) {
						removeIndex = i;
						System.out.println(removeFileName + "파일 삭제 완료");
						removeResult = true;
						break;
					}
				}
			}
		}

		if (removeResult) {
			uploadFileList.remove(removeIndex); // 리스트에서 삭제
			System.out.println("==============================");
			System.out.println("현재 파일 리스트에 있는 파일들");
			for (BoardUpFilesVODTO f : uploadFileList) {
				System.out.println(f.toString());
			}
			System.out.println("==============================");
			result = new ResponseEntity<MyResponseWithoutData>(new MyResponseWithoutData(200, "", "success"),
					HttpStatus.OK);
		} else {
			result = new ResponseEntity<MyResponseWithoutData>(new MyResponseWithoutData(200, "", "fail"),
					HttpStatus.CONFLICT);

		}

		return result;
	}

	// 취소 처리
//	@GetMapping("/cancelBoard")
	@RequestMapping(value = "/cancelBoard", method = RequestMethod.GET)
	public ResponseEntity<String> cancelBoard(HttpServletRequest request) {
		System.out.println("유저가 업로드한 모든 파일을 삭제하자");
		String realPath = request.getSession().getServletContext().getRealPath("/resources/boardUpFiles");

		allUploadFilesDelete(realPath, uploadFileList);

		return new ResponseEntity<String>("success", HttpStatus.OK);
	}

	private void allUploadFilesDelete(String realPath, List<BoardUpFilesVODTO> fileList) {
		System.out.println(realPath);

		for (int i = 0; i < fileList.size(); i++) {
			fileProcess.removeFile(realPath + fileList.get(i).getNewFileName()); // realPath + \2024\09\05\.jpg
//			System.out.println(i + "번째 : " + fileList.get(i).getNewFileName());

			System.out.println(fileList.get(i).toString());
			// 이미지 파일이면 썸네일 파일 또한 삭제해야 함
			if (fileList.get(i).getThumbFileName() != null) {
				fileProcess.removeFile(realPath + fileList.get(i).getThumbFileName());
			}
		}
	}

	// --------------------게시글 상세페이지 ------------------------------

	@GetMapping("/viewBoard1") // hboard/viewBoard?boardNo=10
	public void viewBoard1(@RequestParam("boardNo") int boardNo, Model model) throws Exception {

//		logger.info(boardNo + "번 글 조회");
		HBoardDTO boardDTO = service.viewBoardByNo(boardNo);
		List<BoardUpFilesVODTO> filesDTO = new ArrayList<BoardUpFilesVODTO>();
		filesDTO = boardDTO.getFileList();
		model.addAttribute("board", boardDTO);
		model.addAttribute("fileList", filesDTO);
	}

	// resultMap 테스트
	@GetMapping("/viewBoard2")
	public void viewBoard2(@RequestParam("boardNo") int boardNo, Model model) {

		HBoardDTO dto = null;
		try {
			dto = service.testResultMap(boardNo);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		model.addAttribute("board", dto);
	}

	// 아래의 viewBoard()는 /viewBoard(게시글 상세보기), /modifyBoard(게시글 수정하기 위해 게시글을 불러오기
	// 위함)일 때
	// 2번 호출된다.
	@GetMapping(value = { "/viewBoard", "/modifyBoard" })
	public String viewBoard(@RequestParam(value = "boardNo", defaultValue = "-1") int boardNo, Model model,
			HttpServletRequest request) {
		System.out.println(request.getRequestURI());

		List<BoardDetailInfo> boarderDetailInfo = null;

		String ipAddr = GetClientIPAddr.getClientIp(request);
		String returnViewPage = "";

		if (boardNo == -1) {
			return "redirect:/hboard/listAll";
		} else {
			try {
				if (request.getRequestURI().equals("/hboard/viewBoard")) {
					System.out.println("게시글 상세보기 호출");
					boarderDetailInfo = service.read(boardNo, ipAddr);
					returnViewPage = "/hboard/viewBoard";
				} else if (request.getRequestURI().equals("/hboard/modifyBoard")) {
					boarderDetailInfo = service.read(boardNo);
					returnViewPage = "/hboard/modifyBoard";

					for (BoardDetailInfo b : boarderDetailInfo) {
						this.modifyFileList = b.getFileList();
					}
					outputModifyFileList();
				}

			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				returnViewPage = "redirect:/hboard/listAll?status=fail";
			}

			model.addAttribute("boardDetailInfo", boarderDetailInfo);
			return returnViewPage;
		}

	}

	// 답글처리
	@GetMapping("/showReplyForm")
	public String showReplyForm() {
		return "/hboard/replyForm";
	}

	@RequestMapping(value = "/saveReply", method = RequestMethod.POST)
	public String saveReplyBoard(HBoardReplyDTO replyBoard, RedirectAttributes rttr) {
		System.out.println("답글 저장 동작");
		System.out.println(replyBoard.toString());

		String returnPage = "redirect:/hboard/listAll";

		try {
			if (service.saveReply(replyBoard)) {
				rttr.addAttribute("status", "success");
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			rttr.addAttribute("status", "fail");
		}
		return returnPage;
	}

	// 게시글 삭제
	@RequestMapping("/removeBoard")
	public String removeBoard(@RequestParam("boardNo") int boardNo, HttpServletRequest request,
			RedirectAttributes rttr) {
		String realPath = request.getSession().getServletContext().getRealPath("/resources/boardUpFiles");
		String returnPage = "redirect:/hboard/listAll";
		try {
			List<BoardUpFilesVODTO> fileList = service.removeBoardByNo(boardNo);

			// 첨부파일이 있다면.. 파일 정보 가져와 하드디스크 삭제
			if (fileList.size() > 0) {
				allUploadFilesDelete(realPath, fileList);
			}
			rttr.addAttribute("status", "removeSuccess");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			rttr.addAttribute("status", "removeFail");
		}
		// 첨부파일이 있다면.. 파일정보 가져와 하드디스크에서 삭제

		return returnPage;
	}

	// 게시글 수정 처리
	@RequestMapping(value = "modifyRemoveFileCheck", method = RequestMethod.POST)
	public ResponseEntity<MyResponseWithoutData> modifyRemoveFileCheck(@RequestParam("removeFileNo") int removeFilePK) {
		System.out.println(removeFilePK + "번 파일 삭제 요청");

		// 아직 최종 수정이 될지는 미지수 상태 : 하드에서 삭제할 수 없는 단계
		// 삭제 될 파일을 체크만 해두고 최종 요청이 들어오면 그 때 실제 삭제처리를 해야 한다.
		for (BoardUpFilesVODTO file : this.modifyFileList) {
			if (removeFilePK == file.getBoardUpFileNo()) {
				file.setFileStatus(BoardUpFileStatus.DELETE);
//				modifyFileList.remove(file);
			}
		}
		outputModifyFileList();

		return new ResponseEntity<MyResponseWithoutData>(new MyResponseWithoutData(200, null, "success"),
				HttpStatus.OK);
	}

	private void outputModifyFileList() {
		System.out.println("==============================");
		System.out.println("현재 파일 리스트에 있는 파일들 (수정시)");
		for (BoardUpFilesVODTO f : this.modifyFileList) {
			System.out.println(f.toString());
		}
		System.out.println("==============================");
	}

	@RequestMapping(value = "cancelRemFiles", method = RequestMethod.POST)
	public ResponseEntity<MyResponseWithoutData> cancelRemFiles() {
		System.out.println("파일리스트의 모든 파일 삭제 취소 요청");
		for (BoardUpFilesVODTO file : this.modifyFileList) {
			file.setFileStatus(null);
		}

		outputModifyFileList();

		return new ResponseEntity<MyResponseWithoutData>(new MyResponseWithoutData(200, null, "success"),
				HttpStatus.OK);
	}

	@RequestMapping(value = "/modifyBoardSave", method = RequestMethod.POST)
	public String modifyBoardSave(HBoardDTO modifyBoard, @RequestParam("modifyNewFile") MultipartFile[] modifyNewFile,
			HttpServletRequest request, RedirectAttributes rttr) {
		String redirectPath = "redirect:/hboard/viewBoard?boardNo=" + modifyBoard.getBoardNo();
		System.out.println(modifyBoard.toString() + "수정");
		try {
			for (int i = 0; i < modifyNewFile.length; i++) {
				// 새로 업로드 된 파일 저장
				BoardUpFilesVODTO fileInfo = fileSave(modifyNewFile[i], request);
				fileInfo.setFileStatus(BoardUpFileStatus.INSERT); // 저장(insert)되어야 할 파일임을 기록
				this.modifyFileList.add(fileInfo);
			}
			outputModifyFileList();

			// DB에 저장
			modifyBoard.setFileList(modifyFileList);
			if (service.updateBoard(modifyBoard)) {
				System.out.println("수정완료");
				rttr.addAttribute("status", "success");
			}

		} catch (Exception e) {
			e.printStackTrace();
			rttr.addAttribute("status", "fail");
		}
//		modifyFileList.clear();
		return redirectPath;
	}
}
