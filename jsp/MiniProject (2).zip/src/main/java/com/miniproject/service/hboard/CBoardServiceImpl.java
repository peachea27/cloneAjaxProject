package com.miniproject.service.hboard;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.miniproject.model.BoardDetailInfo;
import com.miniproject.model.HBoardDTO;
import com.miniproject.model.HBoardReplyDTO;
import com.miniproject.model.HBoardVO;
import com.miniproject.model.PagingInfo;
import com.miniproject.model.PagingInfoDTO;
import com.miniproject.model.PointLogDTO;
import com.miniproject.model.SearchCriteriaDTO;
import com.miniproject.persistence.CBoardDAO;
import com.miniproject.persistence.HBoardDAO;
import com.miniproject.persistence.MemberDAO;
import com.miniproject.persistence.PointLogDAO;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RequiredArgsConstructor
@Service
public class CBoardServiceImpl implements CBoardService {

	private final CBoardDAO cDao;
	private final HBoardDAO hDao;
	private final PointLogDAO pDao;
	private final MemberDAO mDao;

	@Override
	public Map<String, Object> getAllBoard(PagingInfoDTO dto) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	@Transactional(rollbackFor = Exception.class, propagation = Propagation.REQUIRED, isolation = Isolation.DEFAULT)
	public boolean saveBoard(HBoardDTO newBoard) throws Exception {
		boolean result = false;

		// 1) newboard를 DAO단을 통해서 insert한다.
		if (cDao.insertNewBoard(newBoard) == 1) {
			// 2) 1)에서 insert가 성공하면, pointlog에 저장
			if (pDao.insertPointLog(new PointLogDTO(newBoard.getWriter(), "글작성")) == 1) {
				// 3)작성자의 userPoint값을 update한다.
				if (mDao.updateUserPoint(newBoard.getWriter()) == 1) {
					result = true;
				}
			}
		}
		return result;

	}

	@Override
	public HBoardDTO viewBoardByNo(int boardNo) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public HBoardDTO testResultMap(int boardNo) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	@Transactional(rollbackFor = Exception.class)
	public BoardDetailInfo read(int boardNo, String ipAddr) throws Exception {
		BoardDetailInfo boardInfo = cDao.selectBoardDetailByBoardNo(boardNo);

		int dateDiff = hDao.selectDateDiff(ipAddr, boardNo);
		System.out.println("dateDiff 출력 : " + dateDiff);
		if (dateDiff == -1) { // 해당 아이피 주소가 boardNo번 글을 최초로 조회
			// 아이피주소가 boardNo번 글을 읽은 시간을 테이블에 저장 (insert)
			if (hDao.insertBoardReadLog(ipAddr, boardNo) == 1) {
				// 조회수 증가
				updateReadCount(boardNo, boardInfo);
			}
		} else if (dateDiff >= 1) { // 해당 아이피 주소가 boardNo번 글을 다시 조회 (24시간 지났을 때)
			// 아이피 주소가 boardNo번 글을 읽은 시간을 테이블에 수정 (update)
			hDao.updateReadWhen(ipAddr, boardNo);
			// 조회수 증가 (+1)
			updateReadCount(boardNo, boardInfo);
		}
		return boardInfo;
	}

	@Override
	public boolean saveReply(HBoardReplyDTO replyBoard) throws Exception {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int removeBoardByNo(int boardNo) throws Exception {
		return cDao.removeBoardByNo(boardNo);
	}

	@Override
	public BoardDetailInfo read(int boardNo) throws Exception {
		return cDao.selectBoardDetailByBoardNo(boardNo);
	}

	@Override
	public boolean updateBoard(HBoardDTO modifyBoard) throws Exception {
		boolean result = false;

		// 1) 순수게시글 update
		if (cDao.updateBoard(modifyBoard) == 1) {
			result = true;
		}
		return result;
	}

	@Override
	public Map<String, Object> getAllBoard(PagingInfoDTO dto, SearchCriteriaDTO searchCriteriaDTO) throws Exception {

		PagingInfo pi = makePagingInfo(dto, searchCriteriaDTO);
//		searchCriteriaDTO.setSearchWord("%" + searchCriteriaDTO.getSearchWord() + "%");
		List<HBoardVO> lst = cDao.selectAllBoard(pi, searchCriteriaDTO);

		Map<String, Object> resultMap = new HashMap<String, Object>();
		resultMap.put("pagingInfo", pi);
		resultMap.put("boardList", lst);

		return resultMap;
	}

	private PagingInfo makePagingInfo(PagingInfoDTO dto, SearchCriteriaDTO searchCriteriaDTO) throws Exception {
		PagingInfo pi = new PagingInfo(dto);
		System.out.println("DTO : " + dto.toString());
		// setter 호출
		pi.setTotalPostCnt(cDao.getTotalPostCnt(searchCriteriaDTO)); // 검색된 글(데이터)의 수
		System.out.println("검색된 글 총 수 " + pi.getTotalPostCnt());

		pi.setTotalPageCnt(); // 전체 페이지 수 세팅
		pi.setStartRowIndex(); // 현재 페이지에서 보여주기 시작할 글의 index번호

		// 페이징 블럭
		pi.setPageBlockNoCurPage();
		pi.setStartPageNoCurBlock();
		pi.setEndPageNoCurBlock();

		System.out.println(pi.toString());
		return pi;
	}

	private void updateReadCount(int boardNo, BoardDetailInfo boardInfo) throws Exception {
		if (hDao.updateReadCount(boardNo) == 1) {
			boardInfo.setReadCount(boardInfo.getReadCount() + 1);
		}
	}

	@Override
	@Transactional
	public boolean likeBoard(int boardNo, String who) throws Exception {
		boolean result = false;
		// 좋아요
		// 1) boardlike 테이블에 저장 (insert)
		if (cDao.likeBoard(boardNo, who) == 1) {

			// 2)hboard의 likecount를 업데이트 (+1)
			if (cDao.updateBoardLikeCount(1, boardNo) == 1) {
				result = true;
			}
		}
		return result;
	}

	@Override
	@Transactional
	public boolean dislikeBoard(int boardNo, String who) throws Exception {
		boolean result = false;

		// 1) boardlike테이블에서 삭제 (delete)
		if (cDao.dislikeBoard(boardNo, who) == 1) {
			if (cDao.updateBoardLikeCount(-1, boardNo) == 1) {
				result = true;
			}
		}

		return false;
	}

	@Override
	public List<String> selectPeopleWhoLike(int boardNo) throws Exception {
		return cDao.selectPeopleWhoLikeBoard(boardNo);
	}
}
