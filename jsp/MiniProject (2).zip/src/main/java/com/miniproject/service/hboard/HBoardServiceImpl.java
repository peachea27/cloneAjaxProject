package com.miniproject.service.hboard;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.miniproject.model.BoardDetailInfo;
import com.miniproject.model.BoardUpFileStatus;
import com.miniproject.model.BoardUpFilesVODTO;
import com.miniproject.model.HBoardDTO;
import com.miniproject.model.HBoardReplyDTO;
import com.miniproject.model.HBoardVO;
import com.miniproject.model.PagingInfo;
import com.miniproject.model.PagingInfoDTO;
import com.miniproject.model.PointLogDTO;
import com.miniproject.model.SearchCriteriaDTO;
import com.miniproject.persistence.HBoardDAO;
import com.miniproject.persistence.MemberDAO;
import com.miniproject.persistence.PointLogDAO;

import lombok.extern.slf4j.Slf4j;

// service단에서 해야 할 직업
// 1) Controller에서 넘겨진 파라미터를 처리한 후 (비즈로직에 의해.. 트랜잭션 처리를 통해)
// 2) DB작업이 필요하다면 DAO단 호출...
// 3) DAO단에서 반환된 값을 Controller단으로 넘겨준다.

@Slf4j
@Service // �Ʒ��� Ŭ������ ���� ��ü���� �����Ϸ� ����
public class HBoardServiceImpl implements HBoardService {

	@Inject
	private HBoardDAO bDao;

	@Inject
	private PointLogDAO pDao;
	@Inject
	private MemberDAO mDao;

	@Override
	public Map<String, Object> getAllBoard(PagingInfoDTO dto) throws Exception {
		PagingInfo pi = makePagingInfo(dto);
		List<HBoardVO> lst = bDao.selectAllBoard(pi);
		Map<String, Object> resultMap = new HashMap<String, Object>();
		resultMap.put("pagingInfo", pi);
		resultMap.put("boardList", lst);
		return resultMap;
	}

	private PagingInfo makePagingInfo(PagingInfoDTO dto) throws Exception {
		PagingInfo pi = new PagingInfo(dto);
		System.out.println("DTO : " + dto.toString());
		// setter 호출
		pi.setTotalPostCnt(bDao.getTotalPostCnt()); // 전체 글(데이터)의 수
		System.out.println(pi.getTotalPostCnt());

		pi.setTotalPageCnt(); // 전체 페이지 수 세팅
		pi.setStartRowIndex(); // 현재 페이지에서 보여주기 시작할 글의 index번호

		// 페이징 블럭
		pi.setPageBlockNoCurPage();
		pi.setStartPageNoCurBlock();
		pi.setEndPageNoCurBlock();

		System.out.println(pi.toString());
		return pi;
	}

	@Override
	@Transactional(rollbackFor = Exception.class, propagation = Propagation.REQUIRED, isolation = Isolation.DEFAULT)
	public boolean saveBoard(HBoardDTO newBoard) throws Exception {
		boolean result = false;

		// 1) newboard를 DAO단을 통해서 insert한다.
		if (bDao.insertNewBoard(newBoard) == 1) {
			// 첨부파일이 있다면, 첨부파일 또한 저장한다. boardNo =?
			// 1-1) 방금 저장된 게시글의 번호
			int newBoardNo = bDao.selectMaxBoardNo();

			// 1-1-1) 1-1)에서 가져온 글 번호를 ref칼럼에 update
			bDao.updateBoardRef(newBoardNo);
			// 1-2) 1-1)에서 얻어온 게시글 번호를 참조하는 첨부파일정보를 insert해야 한다.

			for (BoardUpFilesVODTO file : newBoard.getFileList()) {
				file.setBoardNo(newBoardNo);
				bDao.insertBoardUpFile(file);
			}
			// 2) 1)에서 insert가 성공하면, pointlog에 저장
			if (pDao.insertPointLog(new PointLogDTO(newBoard.getWriter(), "글작성")) == 1) {
				// 3)작성자의 userPoint값을 update한다.
				if (mDao.updateUserPoint(newBoard.getWriter()) == 1) {
					result = true;
				}
			}
		}
		return result;

	}

	@Override
	public HBoardDTO viewBoardByNo(int boardNo) throws Exception {
		HBoardDTO boardDTO = bDao.selectBoardByNo(boardNo);
		List<BoardUpFilesVODTO> filesDTO = new ArrayList<BoardUpFilesVODTO>();
		filesDTO = bDao.selectFileByNo(boardNo);
		boardDTO.setFileList(filesDTO);
		System.out.println("서비스단 DTO : " + boardDTO.toString());
		return boardDTO;
	}

	@Override
	public HBoardDTO testResultMap(int boardNo) throws Exception {
		return bDao.testResultMap(boardNo);
	}

	@Override
	@Transactional(rollbackFor = Exception.class)
	public List<BoardDetailInfo> read(int boardNo, String ipAddr) throws Exception {
		List<BoardDetailInfo> boardInfo = bDao.selectBoardDetailByBoardNo(boardNo);

		// 조회수 증가
		// dateDiff = 날짜차이계산결과
		int dateDiff = bDao.selectDateDiff(ipAddr, boardNo);
		System.out.println("dateDiff 출력 : " + dateDiff);
		if (dateDiff == -1) { // 해당 아이피 주소가 boardNo번 글을 최초로 조회
			// 아이피주소가 boardNo번 글을 읽은 시간을 테이블에 저장 (insert)
			if (bDao.insertBoardReadLog(ipAddr, boardNo) == 1) {
				// 조회수 증가
				updateReadCount(boardNo, boardInfo);
			}
		} else if (dateDiff >= 1) { // 해당 아이피 주소가 boardNo번 글을 다시 조회 (24시간 지났을 때)
			// 아이피 주소가 boardNo번 글을 읽은 시간을 테이블에 수정 (update)
			bDao.updateReadWhen(ipAddr, boardNo);
			// 조회수 증가 (+1)
			updateReadCount(boardNo, boardInfo);
		}
		return boardInfo;
	}

	private void updateReadCount(int boardNo, List<BoardDetailInfo> boardInfo) throws Exception {
		if (bDao.updateReadCount(boardNo) == 1) {
			for (BoardDetailInfo b : boardInfo) {
				b.setReadCount(b.getReadCount() + 1);
				System.out.println("조회수 : " + b.getReadCount());
			}
		}
	}

	@Override
	@Transactional(rollbackFor = Exception.class, propagation = Propagation.REQUIRED, isolation = Isolation.DEFAULT)
	public boolean saveReply(HBoardReplyDTO replyBoard) throws Exception {
		boolean result = false;
//		부모글에 대한 다른 답글이 있는 상태에서, 부모글의 답글이 추가되는 경우,
//		-- (자리확보를 위해) 기존의 답글의 refOrder값을 (+1) 수정해야 한다.
		bDao.updateRefOrder(replyBoard.getRef(), replyBoard.getRefOrder());

//		답글을 입력받아서, 달글 저장
//		-- ref = pRef, step = pStep + 1, refOrder = pRefOrder + 1
		replyBoard.setStep(replyBoard.getStep() + 1); // step = pStep +1
		replyBoard.setRefOrder(replyBoard.getRefOrder() + 1); // refOrder = pRefOrdet +1
		if (bDao.insertReplyBoard(replyBoard) == 1)// insert
		{
			result = true;
		}

		return result;
	}

	// 게시글 삭제 처리
	@Override
	@Transactional(rollbackFor = Exception.class)
	public List<BoardUpFilesVODTO> removeBoardByNo(int boardNo) throws Exception {
//		1) 삭제 해야 할 업로드 파일 정보를 불러오자
		List<BoardUpFilesVODTO> fileList = bDao.selectFileByNo(boardNo);
//		2) boardNo번글의 첨부파일을 테이블에서 삭제하자
		bDao.deleteAllBoardUpFiles(boardNo);
//		3) boardNo글을 hobard테이블에서 삭제
		if (bDao.removeBoardByNo(boardNo) == 1) {
			return fileList;
		} else {

			return null;
		}

	}

	@Override
	public List<BoardDetailInfo> read(int boardNo) throws Exception {
		List<BoardDetailInfo> boardInfo = bDao.selectBoardDetailByBoardNo(boardNo);
		return boardInfo;
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRED, isolation = Isolation.DEFAULT, rollbackFor = Exception.class)
	public boolean updateBoard(HBoardDTO modifyBoard) throws Exception {
		boolean result = false;

		// 1) 순수게시글 update
		if (bDao.updateBoard(modifyBoard) == 1) {
			// 2) 업로드파일의 fileStatus = INSERT insert문, DELETE면 delete문
			for (BoardUpFilesVODTO file : modifyBoard.getFileList()) {
				if (file.getFileStatus() == BoardUpFileStatus.INSERT) {
					file.setBoardNo(modifyBoard.getBoardNo()); // 저장되는 파일의 글 번호를 수정되는 글의 글번호로 세팅
					bDao.insertBoardUpFile(file);
				} else if (file.getFileStatus() == BoardUpFileStatus.DELETE) {
					bDao.deleteBoardUpFile(file.getBoardUpFileNo());
				}
			}
			result = true;
		}
		return result;
	}

	@Override
	public Map<String, Object> getAllBoard(PagingInfoDTO dto, SearchCriteriaDTO searchCriteriaDTO) throws Exception {
		PagingInfo pi = makePagingInfo(dto, searchCriteriaDTO);
//		searchCriteriaDTO.setSearchWord("%" + searchCriteriaDTO.getSearchWord() + "%");
		List<HBoardVO> lst = bDao.selectAllBoard(pi, searchCriteriaDTO);

		Map<String, Object> resultMap = new HashMap<String, Object>();
		resultMap.put("pagingInfo", pi);
		resultMap.put("boardList", lst);

		return resultMap;
	}

	private PagingInfo makePagingInfo(PagingInfoDTO dto, SearchCriteriaDTO searchCriteriaDTO) throws Exception {
		PagingInfo pi = new PagingInfo(dto);
		System.out.println("DTO : " + dto.toString());
		// setter 호출
		pi.setTotalPostCnt(bDao.getTotalPostCnt(searchCriteriaDTO)); // 검색된 글(데이터)의 수
		System.out.println("검색된 글 총 수 " + pi.getTotalPostCnt());

		pi.setTotalPageCnt(); // 전체 페이지 수 세팅
		pi.setStartRowIndex(); // 현재 페이지에서 보여주기 시작할 글의 index번호

		// 페이징 블럭
		pi.setPageBlockNoCurPage();
		pi.setStartPageNoCurBlock();
		pi.setEndPageNoCurBlock();

		System.out.println(pi.toString());
		return pi;
	}

}
