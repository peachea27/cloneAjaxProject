package com.miniproject.service.hboard;

import java.util.List;
import java.util.Map;

import com.miniproject.model.BoardDetailInfo;
import com.miniproject.model.HBoardDTO;
import com.miniproject.model.HBoardReplyDTO;
import com.miniproject.model.PagingInfoDTO;
import com.miniproject.model.SearchCriteriaDTO;

public interface CBoardService {

	// 게시글 조회 - 페이징
	Map<String, Object> getAllBoard(PagingInfoDTO dto) throws Exception;

	// 게시글 저장
	public boolean saveBoard(HBoardDTO boardDTO) throws Exception;

	// 게시판 글 조회
	HBoardDTO viewBoardByNo(int boardNo) throws Exception;

	// resultmap 테스트
	HBoardDTO testResultMap(int boardNo) throws Exception;

	// 게시글 상세 조회
	BoardDetailInfo read(int boardNo, String ipAddr) throws Exception;

	// 답글 저장
	boolean saveReply(HBoardReplyDTO replyBoard) throws Exception;

	// 게시글 삭제
	int removeBoardByNo(int boardNo) throws Exception;

	// 게시글 조회(수정)
	BoardDetailInfo read(int boardNo) throws Exception;

	// 게시글 수정
	boolean updateBoard(HBoardDTO modifyBoard) throws Exception;

	// 게시글 검색
	Map<String, Object> getAllBoard(PagingInfoDTO dto, SearchCriteriaDTO searchCriteriaDTO) throws Exception;

	// 게시글 좋아요
	boolean likeBoard(int boardNo, String who) throws Exception;

	// 게시글 좋아요 취소
	boolean dislikeBoard(int boardNo, String who) throws Exception;

	// 해당게시글을 좋아요 한 사람들 조회
	List<String> selectPeopleWhoLike(int boardNo) throws Exception;

}
