package com.miniproject.service.member;

import com.miniproject.model.AutoLoginInfo;
import com.miniproject.model.LoginDTO;
import com.miniproject.model.MemberDTO;

public interface MemberService {
	// 아이디 중복검사
	boolean idIsDuplicate(String tmpUserId) throws Exception;

	// 회원정보 DB에 저장
	boolean saveMember(MemberDTO registerMember) throws Exception;

	// 로그인
	MemberDTO login(LoginDTO loginDTO) throws Exception;

	// 자동로그인 체크한 유저의 정보 저장
	boolean saveAutoLoginInfo(AutoLoginInfo autoLoginInfo) throws Exception;

	// 자동로그인 체크한 유저
	MemberDTO checkAutoLogin(String savedCookieSesId) throws Exception;
}
