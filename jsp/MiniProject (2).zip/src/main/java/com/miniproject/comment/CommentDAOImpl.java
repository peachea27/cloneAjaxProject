package com.miniproject.comment;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;

import com.miniproject.model.CommentDTO;
import com.miniproject.model.CommentVO;
import com.miniproject.model.PagingInfo;

import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@Repository
public class CommentDAOImpl implements CommentDAO {

	private static final String NS = "com.miniproject.mappers.commentmapper.";
	private final SqlSession ses;

	@Override
	public List<CommentVO> getAllComments(int boardNo) throws Exception {
		return ses.selectList(NS + "getComments", boardNo);
	}

	@Override
	public int insertNewComment(CommentDTO newComment) throws Exception {
		return ses.insert(NS + "saveComments", newComment);
	}

	@Override
	public int getTotalPostCnt(int boardNo) throws Exception {
		return ses.selectOne(NS + "getCommentCount", boardNo);
	}

	@Override
	public List<CommentVO> getAllComments(int boardNo, PagingInfo pi) throws Exception {
		Map<String, Object> param = new HashMap<String, Object>();
		param.put("boardNo", boardNo);
		param.put("startRowIndex", pi.getStartRowIndex());
		param.put("viewPostCntPerPage", pi.getViewPostCntPerPage());
		return ses.selectList(NS + "getComments", param);

	}

}
