package com.miniproject.comment;

import java.util.List;

import com.miniproject.model.CommentDTO;
import com.miniproject.model.CommentVO;
import com.miniproject.model.PagingInfo;

public interface CommentDAO {

	List<CommentVO> getAllComments(int boardNo) throws Exception;

	int insertNewComment(CommentDTO newComment) throws Exception;

	// 게시판 댓글 수
	int getTotalPostCnt(int boardNo) throws Exception;

	List<CommentVO> getAllComments(int boardNo, PagingInfo pi) throws Exception;
}
