package com.miniproject.util;

import javax.servlet.http.HttpServletRequest;

// 로그인을 하지 않았을 때, 로그인 페이지로 이동되기 전에, 원래 가려던 페이지 경로를 저장하는 객체
public class DestinationPath {

	private String destPath;
	private int boardNo;

	public void setDestPath(HttpServletRequest req) {
		// 글작성 요청시 uri : /hboard/saveBoard
		// 글수정(삭제) uri : /hboard/modifyBoard?boardNo=330(쿼리스트링이 있다)
		String uri = req.getRequestURI();
		String queryString = req.getQueryString();
//		if (StringUtils.isNullOrEmpty(req.getQueryString())) {
//			this.destPath = uri;
//		} else {
//			this.destPath = uri + "?" + req.getQueryString();
//		}
		destPath = (queryString == null) ? uri : uri + "?" + queryString;
		req.getSession().setAttribute("destPath", destPath);
	}

	public String getDestPath() {
		return this.destPath;
	}
}
