package com.ajaxjsp.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;

import javax.naming.NamingException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

import com.ajaxjsp.dao.EmployeesDAOImpl;
import com.ajaxjsp.vodto.DepartmentsVO;


@WebServlet("/GetAllDepartments.do")
public class GetAllDepartmentsServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
  
    public GetAllDepartmentsServlet() {
        super();
    }


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("GetAllDepts호출됨");
		
		response.setContentType("application/json; charset=utf-8");
		PrintWriter out = response.getWriter();
		EmployeesDAOImpl dao = EmployeesDAOImpl.getInstance();
		
		try {
			List<DepartmentsVO> lst = dao.selectAllDepartments();
			
			JSONObject json = new JSONObject();
			json.put("status", "success");
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy년 MM월 dd일 HH시 mm분 ss초");
			String outputDate = sdf.format(Calendar.getInstance().getTime());
			json.put("outputDate", outputDate);
			json.put("count", lst.size());
			
			if(lst.size() > 0) {
				JSONArray depts = new JSONArray();
				
				for(DepartmentsVO e : lst) {
					JSONObject dept = new JSONObject();
					dept.put("DEPARTMENT_ID", e.getDepartment_id());
					dept.put("DEPARTMENT_NAME", e.getDepartment_name());
					dept.put("MANAGER_ID", e.getManager_id());
					dept.put("LOCATION_ID", e.getLocation_id());
					
					depts.add(dept);
					
				}
				json.put("depts", depts);
			}
			
				String jsonString = json.toJSONString();
				out.print(jsonString);
				out.close();
			
			
		} catch (NamingException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			out.close();
		}
		
		
	}



}
