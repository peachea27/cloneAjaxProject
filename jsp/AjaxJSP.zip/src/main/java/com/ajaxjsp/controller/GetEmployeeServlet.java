package com.ajaxjsp.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Date;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

import javax.naming.NamingException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.simple.JSONObject;

import com.ajaxjsp.dao.EmployeesDAO;
import com.ajaxjsp.dao.EmployeesDAOImpl;
import com.ajaxjsp.etc.OutputJSONForError;
import com.ajaxjsp.vodto.EmployeeDTO;
import com.ajaxjsp.vodto.EmployeeVO;
import com.google.gson.JsonObject;


@WebServlet("/getEmployee.do")
public class GetEmployeeServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
 
    public GetEmployeeServlet() {
        super();
       
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("사원수정 서블릿 empNo :"+request.getParameter("empNo"));
		
		 response.setContentType("application/json; charset=utf-8");
	      PrintWriter out = response.getWriter();
	      
		
		int empNo = Integer.parseInt(request.getParameter("empNo"));
		EmployeesDAO dao = EmployeesDAOImpl.getInstance();
		
		try {
			EmployeeVO e = dao.selectEmployeeByEmpNo(empNo);
			//응답 JSON만들기
		
				JSONObject json = new JSONObject();
			   json.put("status", "success");
			   SimpleDateFormat sdf = new SimpleDateFormat("yyyy년 MM월 dd일 HH시 mm분 ss초");
			   String outputDate = sdf.format(Calendar.getInstance().getTime());
			   json.put("outputDate", outputDate);
			
			  JSONObject employee = new JSONObject();
              employee.put("EMPLOYEE_ID", e.getEmployee_id());
              employee.put("FIRST_NAME", e.getFirst_name());
              employee.put("LAST_NAME", e.getLast_name());
              employee.put("EMAIL" , e.getEmail());
              employee.put("PHONE_NUMBER", e.getPhone_number());
             
              Date tmpDate = e.getHire_date();
              SimpleDateFormat sdfHireDate = new SimpleDateFormat("yyyy-MM-dd");
              employee.put("HIRE_DATE", sdfHireDate.format(tmpDate));
              employee.put("JOB_ID", e.getJob_id());
              employee.put("SALARY", e.getSalary());
              employee.put("COMMISSION_PCT", e.getCommission_pct());
              employee.put("MANAGER_ID", e.getManager_id());
              employee.put("DEPARTMENT_NAME", e.getDepartment_name());
              
              json.put("employee",employee);
              
              out.print(json.toJSONString());
              
		} catch (NamingException | SQLException e) {
			e.printStackTrace();
			out.print(OutputJSONForError.outputJson(e));
		}finally{
			out.flush();
			out.close();
		}
		
				
				
		
//		response.setContentType("application/json; charset=utf-8");
//		
//		PrintWriter out = response.getWriter(); 
//		
//		//파라미터 읽어오기
//		int employId= Integer.parseInt(request.getParameter("employId"));
//		String firstName = request.getParameter("firstName");
//		String lastName = request.getParameter("lastName");
//		String email = request.getParameter("email");
//		String phoneNumber = request.getParameter("phoneNumber");
//		String strHireDate = request.getParameter("hireDate");
//		//Date타입으로 변환
//		Date hireDate =  Date.valueOf(strHireDate);
//		
//		String jobId = request.getParameter("jobId");
//		float salary = Float.parseFloat(request.getParameter("salary"));
//		float commissionPct = Float.parseFloat(request.getParameter("comm"));
//		int managerId = Integer.parseInt(request.getParameter("managerId"));
//		int departmentId = Integer.parseInt(request.getParameter("departmentId"));
//		
//		//저장할 데이터를 DTO객체로 만들어서 DAO로 전송
//		EmployeeDTO empDTO = new EmployeeDTO(employId,firstName, lastName, phoneNumber, email, hireDate, jobId, salary, commissionPct, managerId, departmentId);
//		System.out.println(empDTO.toString());
//		
//		//employee_id(pk)
//		//1)max(employee_id) +1 값을 얻어온다
//		//2) 1)번에서 얻은 값을 다음 저장될 사원의 employee_id에 대입하여 insert문을 실행한다
//		
//		//저장 프로시저 사용
//		
//		EmployeesDAO dao = EmployeesDAOImpl.getInstance();
//		try {
//			int result = dao.modifyEmp(empDTO);
//			//json으로 응답
//			if(result > 0) {
//				JSONObject json = new JSONObject();
//				json.put("status", "성공");
//				
//				SimpleDateFormat sdf = new SimpleDateFormat("yyyy년 MM월 dd일 HH시 mm분 ss초");
//				String outputDate = sdf.format(Calendar.getInstance().getTime());
//				
//				json.put("outputDate", outputDate);
//				
//				out.print(json.toJSONString());
//				
//			}else {
//				JSONObject json = new JSONObject();
//				json.put("status", "에러");
//				
//				SimpleDateFormat sdf = new SimpleDateFormat("yyyy년 MM월 dd일 HH시 mm분 ss초");
//				String outputDate = sdf.format(Calendar.getInstance().getTime());
//				
//				json.put("outputDate", outputDate);
//				
//				out.print(json.toJSONString());
//			}
//		} catch (NamingException | SQLException e) {
//			e.printStackTrace();
//			out.print(OutputJSONForError.outputJson(e));
//		}finally {
//			out.flush();
//			out.close();
//		}
	}



}
