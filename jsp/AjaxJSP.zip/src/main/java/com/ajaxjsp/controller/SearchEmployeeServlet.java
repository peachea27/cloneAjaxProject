package com.ajaxjsp.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ajaxjsp.dao.EmployeesDAO;
import com.ajaxjsp.dao.EmployeesDAOImpl;
import com.ajaxjsp.vodto.EmployeeVO;


@WebServlet("/findEmpByName.do")
public class SearchEmployeeServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
    public SearchEmployeeServlet() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String searchName = request.getParameter("searchName");
		System.out.println("검색어:"+searchName);
		
		EmployeesDAO dao = EmployeesDAOImpl.getInstance();
		
		List<EmployeeVO> lst =dao.selectByEmpName(searchName);
		
	
		
		
	}


}
