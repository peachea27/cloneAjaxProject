package com.ajaxjsp.vodto;

import java.sql.Date;

public class EmployeeDTO {

	private int employee_id;
	private String first_name;
	private String last_name;
	private String email;
	private String phone_number;
	private Date hire_date;
	private String job_id;
	private float salary;
	private float commission_pct;
	private int manager_id;
	private int department_id;
	public EmployeeDTO(int employee_id, String first_name,String last_name, String phone_number, String email, 
			Date hire_date, String job_id, float salary, float commission_pct, int manager_id, int department_id) {
		super();
		this.employee_id = employee_id;
		this.first_name = first_name;
		this.last_name = last_name;
		this.phone_number = phone_number;
		this.email = email;
		this.hire_date = hire_date;
		this.job_id = job_id;
		this.salary = salary;
		this.commission_pct = commission_pct;
		this.manager_id = manager_id;
		this.department_id = department_id;
	}
	public int getEmployee_id() {
		return employee_id;
	}
	public String getFirst_name() {
		return first_name;
	}
	public String getLast_name() {
		return last_name;
	}
	public String getEmail() {
		return email;
	}
	public String getPhone_number() {
		return phone_number;
	}
	public Date getHire_date() {
		return hire_date;
	}
	public String getJob_id() {
		return job_id;
	}
	public float getSalary() {
		return salary;
	}
	public float getCommission_pct() {
		return commission_pct;
	}
	public int getManager_id() {
		return manager_id;
	}
	public int getDepartment_id() {
		return department_id;
	}
	@Override
	public String toString() {
		return "EmployeeDTO [employee_id=" + employee_id + ", first_name=" + first_name + ", last_name=" + last_name
				+ ", email=" + email + ", phone_number=" + phone_number + ", hire_date=" + hire_date + ", job_id="
				+ job_id + ", salary=" + salary + ", commission_pct=" + commission_pct + ", manager_id=" + manager_id
				+ ", department_id=" + department_id + "]";
	}
}
