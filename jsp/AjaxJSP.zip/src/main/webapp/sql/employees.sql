--모든 직원 목록 불러오기 (부서 이름 추가)

select e.*, d.department_name 
from employees e inner join departments d
on e.department_id = d.department_id;

--모든 직급 가져오기
select * from jobs;

--
select * from friends;
-- --친구저장하기 저장 프로시저

--create or replace PROCEDURE proc_insertfriend
--(
-- --in매개변수(프로시저로 보낼 데이터 변수)
-- --out 매개변수(프로시저에서 밖으로 변환될 변수) 등을 선언하는 부분
-- pFriendName IN friends.FRIENDNAME%TYPE,
-- pMobile IN friends.MOBILE%TYPE,
-- pAddr IN friends.ADDR%TYPE 
--)
--AS
----in/out 매개변수는 아니지만, 임시로 프로시저에서 사용할 변수를 선언하는 부분
--    tmp_friendNo friends.FRIENDNO%TYPE;
--BEGIN
----실질적으로 저장 프로시저가 호출될 때 실행 문장들
--    select max(FRIENDNO)+1 into tmp_friendNo from friends;
--    insert into FRIENDS VALUES(tmp_friendNo,pFriendName,pMobile,pAddr);
--    
--END;
--EXECUTE proc_insertfriend('홍길순','010-1111-3333','서울시 구로구');

--사원 저장하기 저장 프로시저
--CREATE OR REPLACE PROCEDURE PROC_SAVEEMP
--(
--    pFIRST_NAME IN EMPLOYEES.FIRST_NAME%TYPE,
--    pLAST_NAME IN EMPLOYEES.LAST_NAME%TYPE,
--    pEMAIL IN EMPLOYEES.EMAIL%TYPE,
--    pPHONE_NUMBER IN EMPLOYEES.PHONE_NUMBER%TYPE,
--    pHIRE_DATE IN EMPLOYEES.HIRE_DATE%TYPE,
--    pJOB_ID IN EMPLOYEES.JOB_ID%TYPE,
--    pSALARY IN EMPLOYEES.SALARY%TYPE,
--    pCOMMISSION_PCT IN EMPLOYEES.COMMISSION_PCT%TYPE,
--    pMANAGER_ID IN EMPLOYEES.MANAGER_ID%TYPE,
--    pDEPARTMENT_ID IN EMPLOYEES.DEPARTMENT_ID%TYPE,
--    result OUT VARCHAR2
--)
--AS
--    tmp_employee_id EMPLOYEES.EMPLOYEE_ID%TYPE;
--BEGIN
--    select max(employee_id)+1 into tmp_employee_id from employees;
--    insert into employees(EMPLOYEE_ID, FIRST_NAME, LAST_NAME, EMAIL, PHONE_NUMBER,HIRE_DATE,
--    JOB_ID,SALARY,COMMISSION_PCT,MANAGER_ID,DEPARTMENT_ID)
--    VALUES(tmp_employee_id, initcap(pFIRST_NAME), initcap(pLAST_NAME), upper(pEMAIL), pPHONE_NUMBER,pHIRE_DATE,
--    pJOB_ID,pSALARY,pCOMMISSION_PCT,pMANAGER_ID,pDEPARTMENT_ID);
--    
--    result := 'SUCCESS';
--    COMMIT;
--    
--    EXCEPTION --Begin부분에 있는 DML문장을 실행할 때 예외가 나면 처리될 문장
--        WHEN OTHERS THEN--모든 예외에 대해서...다음의 문장을 실행
--        result := 'ERROR';
--        ROLLBACK;
--END;

select * from employees;

--사원 정보 수정
--302번 사원 정보 수정
update employees set first_name ='Thurs' where employee_id =302;
commit;

--사원 정보를 수정할 때, 유저가 어떤 값을 수정할지 모른다
--그래서 모든 경우의 쿼리문을 다 만들 수 없다
--1)먼저 수정할 사원의 정보를 데이터입력 UI에 바인딩 시킨다.
--    ->유저가 특정 값을 수정한다.
--    ->모든 값을 가져온다.
--2)모든 칼럼의 값을 update시켜준다.

--사원 삭제
--1)삭제 delete문을 사용하는 경우
--oldEmp 테이블에 퇴사하는 사원을 옮긴 후, delete문을 수행.
--2)delete문을 사용하지 않는 경우
--employees테이블에 quitDate칼럼을 추가한 후, update수행

alter table employees
add quit_date date;

--update문
update employees set quit_date = ? where employee_id=?;

--전체 사원 목록 쿼리 수정
select e.*, d.department_name
from employees e inner join departments d
on e.department_id = d.department_id
where quit_date is  null
order by employee_id;

--사원 이름으로 검색
select e.*, d.department_name
from employees e inner join departments d
on e.department_id = d.department_id
where (lower(first_name) like '%im%' or lower(last_name) like '%im%') and quit_date is null;


update employees set first_name='둘리', last_name='둘',email='DDRL'
,phone_number='010.222.2222',hire_date='24/02/02',job_id='AD_ASST'
,salary=4400,commission_pct=0.02, manager_id=100, department_id=10 where employee_id=301;
rollback;

--?번 사원의 모든 정보 업데이트
select e.*, d.department_name 
from employees e inner join departments d
on e.department_id = d.department_id where employee_id =?;

select * from employees where employ_id=302;



