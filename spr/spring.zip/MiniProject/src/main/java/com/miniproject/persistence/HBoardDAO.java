package com.miniproject.persistence;

import java.util.List;

import com.miniproject.model.BoardDetailInfo;
import com.miniproject.model.BoardUpFilesVODTO;
import com.miniproject.model.HBoardDTO;
import com.miniproject.model.HBoardReplyDTO;
import com.miniproject.model.HBoardVO;

public interface HBoardDAO {
	// 게시판 전체 목록 가져오는 메서드
	List<HBoardVO> selectAllBoard() throws Exception;

	// 게시글 저장
	public int insertNewBoard(HBoardDTO newBoard) throws Exception;

	// 최근 저장된 글의 글번호를 얻어오는 메서드
	int selectMaxBoardNo() throws Exception;

	// 업로드된 첨부파일 저장하는 메서드
	int insertBoardUpFile(BoardUpFilesVODTO file);

	// 게시판 글 조회
	HBoardDTO selectBoardByNo(int boardNo) throws Exception;

	// 파일리스트 가져오기
	List<BoardUpFilesVODTO> selectFileByNo(int boardNo) throws Exception;

	// resultmap 테스트
	HBoardDTO testResultMap(int boardNo) throws Exception;

	// 게시글 상세정보
	List<BoardDetailInfo> selectBoardDetailByBoardNo(int boardNo) throws Exception;

	// 날짜계산
	int selectDateDiff(String ipAddr, int boardNo) throws Exception;

	// 특정 ip사용자가 게시글을 확인한 로그를 삽입!
	int insertBoardReadLog(String ipAddr, int boardNo) throws Exception;

	// 조회수 업데이트
	int updateReadCount(int boardNo) throws Exception;

	// 24시간이 지났을때 시간 업데이트
	int updateReadWhen(String ipAddr, int boardNo) throws Exception;
	//저장된 게시글의 글번호를 ref칼럼에 update
	void updateBoardRef(int newBoardNo) throws Exception;
	
	//refOrder업데이트 답글처리:자리확보
	void updateRefOrder(int ref, int refOrder) throws Exception;
	
	//답글 저장
	int insertReplyBoard(HBoardReplyDTO replyBoard)  throws Exception;
	
//	int deleteContent(int boardNo) throws Exception;
//	
//	void updateItsDeleted() throws Exception;
	//업로드파일 삭제
	void deleteAllBoardUpFiles(int boardNo);
	
	int deleteBoardByBoardNo(int boardNo);
	
	int modifyContent(HBoardDTO modifyBoard) throws Exception;
	
}
