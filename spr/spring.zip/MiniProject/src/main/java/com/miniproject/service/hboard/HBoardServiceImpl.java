package com.miniproject.service.hboard;

import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.miniproject.model.BoardDetailInfo;
import com.miniproject.model.BoardUpFilesVODTO;
import com.miniproject.model.HBoardDTO;
import com.miniproject.model.HBoardReplyDTO;
import com.miniproject.model.HBoardVO;
import com.miniproject.model.PointLogDTO;
import com.miniproject.persistence.HBoardDAO;
import com.miniproject.persistence.MemberDAO;
import com.miniproject.persistence.PointLogDAO;

import lombok.extern.slf4j.Slf4j;

// service단에서 해야 할 직업
// 1) Controller에서 넘겨진 파라미터를 처리한 후 (비즈로직에 의해.. 트랜잭션 처리를 통해)
// 2) DB작업이 필요하다면 DAO단 호출...
// 3) DAO단에서 반환된 값을 Controller단으로 넘겨준다.

@Slf4j
@Service // �Ʒ��� Ŭ������ ���� ��ü���� �����Ϸ� ����
public class HBoardServiceImpl implements HBoardService {

	@Inject
	private HBoardDAO bDao;

	@Inject
	private PointLogDAO pDao;
	@Inject
	private MemberDAO mDao;

	@Override
	public List<HBoardVO> getAllBoard() throws Exception {
		System.out.println("HboardServiceImpl.......");
//		bDao.updateItsDeleted();
		List<HBoardVO> lst = bDao.selectAllBoard(); // DAO�޼��� ȣ��

		return lst;
	}

	@Override
	@Transactional(rollbackFor = Exception.class,propagation = Propagation.REQUIRED,isolation = Isolation.DEFAULT)
	//propagation = Propagation.REQUIRED,isolation = Isolation.DEFAULT은 기본값이라서 안적어도..
	public boolean saveBoard(HBoardDTO newBoard) throws Exception {
		boolean result = false;

		// 1) newboard를 DAO단을 통해서 insert(유저가 입력한 텍스트)한다.
		if (bDao.insertNewBoard(newBoard) == 1) {
			// 첨부파일이 있다면, 첨부파일 또한 저장한다. boardNo =?
			// 1-1) 방금 저장된 게시글의 번호
			int newBoardNo = bDao.selectMaxBoardNo();
			
				//1-1-1) 1-1)에서 가져온 글 번호를 ref칼럼에 update
				bDao.updateBoardRef(newBoardNo);
			// 1-2) 1-1)에서 얻어온 게시글 번호를 참조하는 첨부파일정보를 insert해야 한다.

			for (BoardUpFilesVODTO file : newBoard.getFileList()) {
				file.setBoardNo(newBoardNo);
				bDao.insertBoardUpFile(file);
			}
			// 2) 1)에서 insert가 성공하면, pointlog에 저장
			if (pDao.insertPointLog(new PointLogDTO(newBoard.getWriter(), "글작성")) == 1) {
				// 3)작성자의 userPoint값을 update한다.
				if (mDao.updateUserPoint(newBoard.getWriter()) == 1) {
					result = true;
				 }
			}
		}
		
		return result;

	}

	@Override
	public HBoardDTO viewBoardByNo(int boardNo) throws Exception {
		HBoardDTO boardDTO = bDao.selectBoardByNo(boardNo);
		List<BoardUpFilesVODTO> filesDTO = new ArrayList<BoardUpFilesVODTO>();
		filesDTO = bDao.selectFileByNo(boardNo);
		boardDTO.setFileList(filesDTO);
		System.out.println("서비스단 DTO : " + boardDTO.toString());
		return boardDTO;
	}

	@Override
	public HBoardDTO testResultMap(int boardNo) throws Exception {
		return bDao.testResultMap(boardNo);
	}

	@Override
	@Transactional(rollbackFor = Exception.class)
	public List<BoardDetailInfo> read(int boardNo, String ipAddr) throws Exception {
		List<BoardDetailInfo> boardInfo = bDao.selectBoardDetailByBoardNo(boardNo);

		// 조회수 증가
		// dateDiff = 날짜차이계산결과
		int dateDiff = bDao.selectDateDiff(ipAddr, boardNo);
		System.out.println("dateDiff 출력 : " + dateDiff);
		if (dateDiff == -1) { // 해당 아이피 주소가 boardNo번 글을 최초로 조회
			// 아이피주소가 boardNo번 글을 읽은 시간을 테이블에 저장 (insert)
			if (bDao.insertBoardReadLog(ipAddr, boardNo) == 1) {
				// 조회수 증가 (+1)
				updateReadCount(boardNo, boardInfo);
			}
		} else if (dateDiff >= 1) { // 해당 아이피 주소가 boardNo번 글을 다시 조회 (24시간 지났을 때)
			// 아이피 주소가 boardNo번 글을 읽은 시간을 테이블에 수정 (update)
			bDao.updateReadWhen(ipAddr, boardNo);
			// 조회수 증가 (+1)
			updateReadCount(boardNo, boardInfo);
		}
		return boardInfo;
	}

	private void updateReadCount(int boardNo, List<BoardDetailInfo> boardInfo) throws Exception {
		if (bDao.updateReadCount(boardNo) == 1) {
			for (BoardDetailInfo b : boardInfo) {
				b.setReadCount(b.getReadCount() + 1);
				System.out.println("조회수 : " + b.getReadCount());
			}
		}
	}

	@Override
	@Transactional(rollbackFor = Exception.class, propagation = Propagation.REQUIRED, isolation = Isolation.DEFAULT)
	public boolean saveReply(HBoardReplyDTO replyBoard) throws Exception {
		boolean result = false;
		//부모글에 대한 다른 답글이 있는 상태에서, 부모의 답글이 추가되는 경우,
		//(자리확보를 위해 )ㅣ기존의 답글의 refOrder값을 수정(+1)해야 한다
		bDao.updateRefOrder(replyBoard.getRef(),replyBoard.getRefOrder());//update
		
		//답글을 입력받아서, 답글 저장
		//--ref=pRef, step= pstep+1, refOrder=pRefOrder+1로 등록한다 
		replyBoard.setStep(replyBoard.getStep()+1);//step=pStep+1
		replyBoard.setRefOrder(replyBoard.getRefOrder()+1);//refOrder=pRefOrder+1
		if(bDao.insertReplyBoard(replyBoard)==1) {//insert
		result = true;
		}
		return result;
	}

//	@Override
//	public int updateY(int boardNo) throws Exception {
//		System.out.println("service-delete");
//		return bDao.deleteContent(boardNo);
//	}

	@Override
	@Transactional(rollbackFor = Exception.class)
	public List<BoardUpFilesVODTO> removeBoard(int boardNo) throws Exception {
		// 게시글 삭제 처리
		// 1) 삭제해야할 업로드파일 정보를 불러오자
		List<BoardUpFilesVODTO> fileList = bDao.selectFileByNo(boardNo);
		// 2)boardNo번글의 첨부파일을 테이블에서 삭제하자
		bDao.deleteAllBoardUpFiles(boardNo);//delete
		// 3)boardNo글을 hboard테이블에서 삭제하자.
		if(bDao.deleteBoardByBoardNo(boardNo)==1) {//update
			return fileList;
		}else {
			return null;
		}
		
		
	}

	@Override
	public List<BoardDetailInfo> read(int boardNo) throws Exception {
		List<BoardDetailInfo> boardInfo = bDao.selectBoardDetailByBoardNo(boardNo);
		return boardInfo;
	}

	@Override
	public boolean modifyContent(HBoardDTO modifyBoard) throws Exception {
		boolean result = false;
		if(bDao.modifyContent(modifyBoard)==1) {
			System.out.println("service"+modifyBoard.getFileList());
//			for(modifyBoard.getFileList())
			result=true;
		}
		System.out.println("serviceImpl result:"+result);
		return result;
	}

//	@Override
//	@Transactional(rollbackFor = Exception.class,propagation = Propagation.REQUIRED,isolation = Isolation.DEFAULT)
//	//propagation = Propagation.REQUIRED,isolation = Isolation.DEFAULT은 기본값이라서 안적어도..
//	public boolean saveBoard(HBoardDTO newBoard) throws Exception {
//		boolean result = false;
//
//		// 1) newboard를 DAO단을 통해서 insert(유저가 입력한 텍스트)한다.
//		if (bDao.insertNewBoard(newBoard) == 1) {
//			// 첨부파일이 있다면, 첨부파일 또한 저장한다. boardNo =?
//			// 1-1) 방금 저장된 게시글의 번호
//			int newBoardNo = bDao.selectMaxBoardNo();
//			
//				//1-1-1) 1-1)에서 가져온 글 번호를 ref칼럼에 update
//				bDao.updateBoardRef(newBoardNo);
//			// 1-2) 1-1)에서 얻어온 게시글 번호를 참조하는 첨부파일정보를 insert해야 한다.
//
//			for (BoardUpFilesVODTO file : newBoard.getFileList()) {
//				file.setBoardNo(newBoardNo);
//				bDao.insertBoardUpFile(file);
//			}
//			// 2) 1)에서 insert가 성공하면, pointlog에 저장
//			if (pDao.insertPointLog(new PointLogDTO(newBoard.getWriter(), "글작성")) == 1) {
//				// 3)작성자의 userPoint값을 update한다.
//				if (mDao.updateUserPoint(newBoard.getWriter()) == 1) {
//					result = true;
//				 }
//			}
//		}
//		
//		return result;
//
//	}


}
