package com.miniproject.persistence;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;

import com.miniproject.model.BoardDetailInfo;
import com.miniproject.model.BoardUpFilesVODTO;
import com.miniproject.model.HBoardDTO;
import com.miniproject.model.HBoardReplyDTO;
import com.miniproject.model.HBoardVO;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Repository // �Ʒ��� Ŭ������ DAO��ü���� ���
public class HBoardDAOImpl implements HBoardDAO {

	@Inject
	private SqlSession ses;

	private static String ns = "com.miniproject.mappers.hboardmapper.";

	@Override
	public List<HBoardVO> selectAllBoard() {
		System.out.println("HBoardDAOImpl..............");
		log.info("HBoardDAOImpl.............");

		return ses.selectList(ns + "getAllHBoard");
	}

	@Override
	public int insertNewBoard(HBoardDTO newBoard) throws Exception {
		int result = ses.insert(ns + "saveNewBoard", newBoard);
		return result;
	}

	@Override
	public int selectMaxBoardNo() throws Exception {
		return ses.selectOne(ns + "getMaxNo");
	}

	@Override
	public int insertBoardUpFile(BoardUpFilesVODTO file) {
		return ses.insert(ns + "saveUpFile", file);
	}

	@Override
	public HBoardDTO selectBoardByNo(int boardNo) throws Exception {
		// TODO Auto-generated method stub
		return ses.selectOne(ns + "getBoardByNo", boardNo);
	}

	@Override
	public List<BoardUpFilesVODTO> selectFileByNo(int boardNo) throws Exception {
		return ses.selectList(ns + "getFilesByNo", boardNo);
	}

	@Override
	public HBoardDTO testResultMap(int boardNo) throws Exception {
		return ses.selectOne(ns + "selectResultmapTest", boardNo);
	}

	@Override
	public List<BoardDetailInfo> selectBoardDetailByBoardNo(int boardNo) throws Exception {
		return ses.selectList(ns + "selectBoardDetailInfoByBoardNo", boardNo);
	}

	@Override
	public int selectDateDiff(String ipAddr, int boardNo) throws Exception {
		//넘겨줘야할 파라미터가 2개 이상이면, Map을 이용하여 파라미터를 매핑하여 넘겨준다
		Map<String, Object> args = new HashMap<String, Object>();
		args.put("readWho", ipAddr);//mapper에서 쓰는 이름으로 
		args.put("boardNo", boardNo);
		return ses.selectOne(ns + "selectBoardDateDiff", args);
	}

	@Override
	public int insertBoardReadLog(String ipAddr, int boardNo) throws Exception {
		Map<String, Object> args = new HashMap<String, Object>();
		args.put("readWho", ipAddr);
		args.put("boardNo", boardNo);
		return ses.insert(ns + "saveBoardReadLog", args);
	}


	@Override
	public int updateReadWhen(String ipAddr, int boardNo) throws Exception {
		Map<String, Object> args = new HashMap<String, Object>();
		args.put("readWho", ipAddr);
		args.put("boardNo", boardNo);
		return ses.update(ns + "updateBoardReadLog", args);
	}

	@Override
	public int updateReadCount(int boardNo) throws Exception {
		return ses.update(ns + "updateReadCount", boardNo);
	}

	@Override
	public void updateBoardRef(int newBoardNo) throws Exception {
		ses.update(ns+"updateBoardRef",newBoardNo);
	}

	@Override
	public void updateRefOrder(int ref, int refOrder) throws Exception {
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("ref", ref);
		params.put("refOrder", refOrder);
		
		ses.update(ns+"updateBoardRefOrder",params);
	}

	@Override
	public int insertReplyBoard(HBoardReplyDTO replyBoard) throws Exception {
		return ses.insert(ns+"insertReplyBoard",replyBoard);
	}

	@Override
	public void deleteAllBoardUpFiles(int boardNo) {
		ses.delete(ns+"deleteBoardUpfileByPK",boardNo);
		
	}

	@Override
	public int deleteBoardByBoardNo(int boardNo) {
		return ses.update(ns+"deleteBoardByBoardNo",boardNo);
		
	}

	@Override
	public int modifyContent(HBoardDTO modifyBoard) throws Exception{
		int result=ses.update(ns+"modifyCont",modifyBoard);
		System.out.println("dalm" + modifyBoard);
		System.out.println("daoImpl 수정되었을까요?: "+ result);
		return result;
	}


}
