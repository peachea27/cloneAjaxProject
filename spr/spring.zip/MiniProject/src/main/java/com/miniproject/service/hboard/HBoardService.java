package com.miniproject.service.hboard;

import java.util.List;

import com.miniproject.model.BoardDetailInfo;
import com.miniproject.model.BoardUpFilesVODTO;
import com.miniproject.model.HBoardDTO;
import com.miniproject.model.HBoardReplyDTO;
import com.miniproject.model.HBoardVO;

public interface HBoardService {

	// �Խ��� ��ü ����Ʈ ��ȸ
	List<HBoardVO> getAllBoard() throws Exception;

	// 게시글 저장
	public boolean saveBoard(HBoardDTO boardDTO) throws Exception;

	// 게시판 글 조회
	HBoardDTO viewBoardByNo(int boardNo) throws Exception;

	// resultmap 테스트
	HBoardDTO testResultMap(int boardNo) throws Exception;

	// 게시글 상세 조회
	List<BoardDetailInfo> read(int boardNo, String ipAddr) throws Exception;

	//답글 저장
	boolean saveReply(HBoardReplyDTO replyBoard) throws Exception;
	
	List<BoardUpFilesVODTO> removeBoard(int boardNo) throws Exception;
	
	//게시글조회(수정)
	List<BoardDetailInfo> read(int boardNo)  throws Exception;
	
	public boolean modifyContent(HBoardDTO modifyBoard) throws Exception;

}
