package com.springbasic.persistence;

public interface ExTxDAO {
	int insertDataTblA(String data);
	
	int insertDataTblB(String data);
}
