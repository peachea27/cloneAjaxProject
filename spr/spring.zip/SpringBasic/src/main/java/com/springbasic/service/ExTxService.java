package com.springbasic.service;

public interface ExTxService {
	
	void saveData(String data) throws Exception;
	
	
	
}
