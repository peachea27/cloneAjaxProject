package com.miniproject.persistence;

import java.util.List;

import javax.inject.Inject;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;

import com.miniproject.model.HBoardDTO;
import com.miniproject.model.HBoardVO;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Repository //�Ʒ��� Ŭ������ DAO��ü���� ����
public class HBoardDAOImpl implements HBoardDAO {

	@Inject
	private SqlSession ses;
	
	private static String ns ="com.miniproject.mappers.hboardmapper.";
	
	
	@Override
	public List<HBoardVO> selectAllBoard() {
		System.out.println("HBoardDAOImpl..............");
		log.info("HBoardDAOImpl.............");
		
		return ses.selectList(ns + "getAllHBoard");
	}


	@Override
	public int insertNewBoard(HBoardDTO newBoard)throws Exception {
		return ses.insert(ns + "saveNewBoard", newBoard);
		
	}

}
