package com.miniproject.persistence;

import org.springframework.stereotype.Repository;

import com.miniproject.model.PointLogDTO;


public interface PointLogDAO {
	//pointlog�� �����ϴ� �޼���
	int insertPointLog(PointLogDTO pointLogDTO) throws Exception;
}
